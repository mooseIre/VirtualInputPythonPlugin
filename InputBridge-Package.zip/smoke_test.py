﻿import sys
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "python"))

from virtual_input import BUTTON_X1, BUTTON_X2, InputBridge, list_devices


devices = list_devices()
print("devices=", devices)

with InputBridge() as bridge:
    bridge.key_up()
    bridge.mouse_up()
    bridge.mouse_move(1, 0)
    bridge.mouse_move(-1, 0)
    bridge.mouse_click(BUTTON_X1)
    bridge.mouse_click(BUTTON_X2)
    bridge.wheel_up(1)
    bridge.wheel_down(1)
    bridge.mouse_move_abs(16384, 16384)

print("smoke=ok")
