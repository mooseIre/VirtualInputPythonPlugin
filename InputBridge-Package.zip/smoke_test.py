import sys
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "python"))

from virtual_input import InputBridge, list_devices


devices = list_devices()
print("devices=", devices)

with InputBridge() as bridge:
    bridge.key_up()
    bridge.mouse_up()
    bridge.mouse_move(1, 0)
    bridge.mouse_move(-1, 0)
    bridge.mouse_move_abs(16384, 16384)

print("smoke=ok")
