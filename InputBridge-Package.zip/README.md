﻿# InputBridge Package

## Requirements

- Windows x64.
- Python 3 in `PATH` or available through the `py -3` launcher for Python smoke test and external calls.
- Secure Boot must be disabled before enabling Windows test mode.
- Windows test mode must be enabled and Windows must be rebooted before installing this test-signed driver.

## Usage

Run the single `manage-driver.bat` file as Administrator and choose an option:

- `1` Install driver.
- `2` Uninstall driver cleanly.
- `3` Run Python smoke test.
- `4` Enable Windows test mode.
- `5` Disable Windows test mode.
- `6` Show driver status.

The same file also supports command mode:

```bat
manage-driver.bat install
manage-driver.bat uninstall
manage-driver.bat test
manage-driver.bat testmode-on
manage-driver.bat testmode-off
manage-driver.bat status
```

## Python Calls

Use `python/virtual_input.py` from your own Python program:

```python
from virtual_input import BUTTON_X1, InputBridge, MOD_LEFT_CTRL

with InputBridge() as bridge:
    bridge.key_combo([0x16], modifiers=MOD_LEFT_CTRL)  # Ctrl+S
    bridge.mouse_move(300, 120, duration_ms=500)
    bridge.human_mouse_move(300, -80, duration_ms=700, jitter=2.0)
    bridge.human_mouse_move(-180, 90, duration_ms=850, jitter=1.2)
    bridge.mouse_click(BUTTON_X1)
    bridge.wheel_down(3)
```

Supported operations include keyboard press, hold, combinations, mouse click, side buttons `BUTTON_X1`/`BUTTON_X2`, wheel up/down, relative movement, timed movement, absolute movement, and humanized movement with jitter.

`human_mouse_move()` uses eased timing, a subtle curved path, settling jitter, and small timing variations between reports so movement is less mechanically uniform while still landing on the exact requested delta.
