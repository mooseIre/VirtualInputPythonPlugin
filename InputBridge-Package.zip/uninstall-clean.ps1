$ErrorActionPreference = "Continue"

$logPath = Join-Path $PSScriptRoot "manage-driver.log"

function Write-Log {
    param([string]$Message)
    $Message | Tee-Object -FilePath $logPath -Append
}

Write-Log "Removing InputBridge devices..."
pnputil /remove-device /deviceid "ROOT\InputBridgeDevice" /subtree /force 2>&1 | Tee-Object -FilePath $logPath -Append

Write-Log "Deleting InputBridge driver packages..."
$driverListPath = Join-Path $env:TEMP "inputbridge-drivers.txt"
& pnputil.exe /enum-drivers | Out-File -FilePath $driverListPath -Encoding utf8

$packages = New-Object System.Collections.Generic.List[string]
$lines = [System.IO.File]::ReadAllLines($driverListPath, [System.Text.Encoding]::UTF8)
for ($index = 0; $index -lt $lines.Count; $index++) {
    if ($lines[$index] -notmatch 'inputbridge\.inf') {
        continue
    }

    $providerWindow = ($lines[$index..([Math]::Min($lines.Count - 1, $index + 4))] -join "`n")
    if ($providerWindow -notmatch 'MooseIre') {
        continue
    }

    for ($scan = $index; $scan -ge [Math]::Max(0, $index - 6); $scan--) {
        if ($lines[$scan] -match '(oem\d+\.inf)') {
            $packages.Add($Matches[1])
            break
        }
    }
}

foreach ($package in ($packages | Select-Object -Unique)) {
    Write-Log "Deleting $package"
    & pnputil.exe /delete-driver $package /uninstall /force 2>&1 | Tee-Object -FilePath $logPath -Append
}

Write-Log "Removing InputBridge test certificate..."
Get-ChildItem Cert:\LocalMachine\Root,Cert:\LocalMachine\TrustedPublisher -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq 'CN=InputBridge Test Certificate' } |
    Remove-Item -Force -ErrorAction SilentlyContinue

Write-Log "Uninstall clean step completed."
