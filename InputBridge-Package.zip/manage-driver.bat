@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
set "ROOT=%CD%"
set "DRIVER_DIR=%ROOT%\driver"
set "PYTHON_DIR=%ROOT%\python"
set "TOOLS_DIR=%ROOT%\tools"
set "DEVCON=%TOOLS_DIR%\devcon.exe"
set "INF=%DRIVER_DIR%\InputBridge.inf"
set "CERT=%DRIVER_DIR%\InputBridgeTest.cer"
set "LOG=%ROOT%\manage-driver.log"

net session >nul 2>&1
if errorlevel 1 (
    echo This script requires Administrator privileges.
    echo Requesting elevation...
    if "%~1"=="" (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    ) else (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '%~1' -Verb RunAs"
    )
    exit /b
)

set "COMMAND_MODE="
if /i "%~1"=="install" (
    set "COMMAND_MODE=1"
    goto install
)
if /i "%~1"=="uninstall" (
    set "COMMAND_MODE=1"
    goto uninstall
)
if /i "%~1"=="test" (
    set "COMMAND_MODE=1"
    goto test
)
if /i "%~1"=="testmode-on" (
    set "COMMAND_MODE=1"
    goto testmode_on
)
if /i "%~1"=="testmode-off" (
    set "COMMAND_MODE=1"
    goto testmode_off
)
if /i "%~1"=="status" (
    set "COMMAND_MODE=1"
    goto status
)

:menu
cls
echo InputBridge Driver Manager
echo.
echo Test-signed kernel drivers require:
echo   1. Secure Boot disabled in BIOS/UEFI
echo   2. Windows test mode enabled
echo   3. Reboot after changing test mode
echo.
echo [1] Install driver
echo [2] Uninstall driver cleanly
echo [3] Run Python smoke test
echo [4] Enable Windows test mode
echo [5] Disable Windows test mode
echo [6] Show driver status
echo [0] Exit
echo.
set /p "CHOICE=Select: "

if "%CHOICE%"=="1" goto install
if "%CHOICE%"=="2" goto uninstall
if "%CHOICE%"=="3" goto test
if "%CHOICE%"=="4" goto testmode_on
if "%CHOICE%"=="5" goto testmode_off
if "%CHOICE%"=="6" goto status
if "%CHOICE%"=="0" exit /b 0
goto menu

:install
call :log_header install
call :check_files || goto done
echo Importing test certificate...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Import-Certificate -FilePath '%CERT%' -CertStoreLocation Cert:\LocalMachine\Root | Out-Null; Import-Certificate -FilePath '%CERT%' -CertStoreLocation Cert:\LocalMachine\TrustedPublisher | Out-Null"

echo Checking existing device...
"%DEVCON%" status "ROOT\InputBridgeDevice" > "%TEMP%\inputbridge-status.txt" 2>&1
type "%TEMP%\inputbridge-status.txt" >> "%LOG%"
findstr /c:"No matching devices found." "%TEMP%\inputbridge-status.txt" >nul
if errorlevel 1 (
    echo Existing InputBridge device found. Skipping device creation.
    del "%TEMP%\inputbridge-status.txt" >nul 2>&1
    goto done
)
del "%TEMP%\inputbridge-status.txt" >nul 2>&1

echo Installing ROOT\InputBridgeDevice...
"%DEVCON%" install "%INF%" "ROOT\InputBridgeDevice" >> "%LOG%" 2>&1
if errorlevel 1 (
    echo Install failed. See "%LOG%".
    goto done
)
echo Install completed.
goto done

:uninstall
call :log_header uninstall
echo Removing InputBridge devices...
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%\uninstall-clean.ps1"

echo Uninstall completed. Logs and temporary files were removed.
goto done

:test
call :log_header test
where python >nul 2>&1
if errorlevel 1 (
    echo Python was not found in PATH.
    goto done
)
python "%ROOT%\smoke_test.py"
goto done

:testmode_on
call :log_header testmode_on
echo Enabling Windows test mode...
bcdedit /set testsigning on >> "%LOG%" 2>&1
if errorlevel 1 (
    echo Failed. Disable Secure Boot in BIOS/UEFI first, then run this option again.
    goto done
)
echo Test mode enabled. Reboot Windows before installing the driver.
goto done

:testmode_off
call :log_header testmode_off
echo Disabling Windows test mode...
bcdedit /set testsigning off >> "%LOG%" 2>&1
if errorlevel 1 (
    echo Failed. See "%LOG%".
    goto done
)
echo Test mode disabled. Reboot Windows for the change to fully apply.
goto done

:status
call :log_header status
echo Device status:
"%DEVCON%" status "ROOT\InputBridgeDevice"
echo.
echo Driver Store packages:
pnputil /enum-drivers | findstr /i "InputBridge MooseIre inputbridge.inf"
goto done

:check_files
if not exist "%DEVCON%" (
    echo Missing "%DEVCON%".
    exit /b 1
)
if not exist "%INF%" (
    echo Missing "%INF%".
    exit /b 1
)
if not exist "%CERT%" (
    echo Missing "%CERT%".
    exit /b 1
)
exit /b 0

:log_header
echo.>> "%LOG%"
echo ==== %~1 %DATE% %TIME% ====>> "%LOG%"
exit /b 0

:done
echo.
if defined COMMAND_MODE exit /b 0
pause
goto menu
